package com.example.beiwanglu2;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.format.Time;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.blankj.utilcode.util.UriUtils;
import com.bumptech.glide.Glide;
import com.example.beiwanglu2.db.MyDbHelper;

import java.io.File;

public class AddInfoActivity extends AppCompatActivity {
    private EditText edit_title, edit_content;
    private Button btn_camera, btn_photo, btn_save;
    private ImageView img_preview;
    private String tmp_path, disp_path;
    private MyDbHelper mhelper;
    private SQLiteDatabase db;
    private File imgfile; // 需要声明 imgfile

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_info);
        ininView();
        btnOnClick();
        btnSave();
    }

    private void ininView(){
        edit_title = findViewById(R.id.editText_title);
        edit_content = findViewById(R.id.editText_content);
        btn_camera = findViewById(R.id.button_camera);
        btn_photo = findViewById(R.id.button_photo);
        btn_save = findViewById(R.id.button_save);
        img_preview = findViewById(R.id.imageView_preview);
        mhelper = new MyDbHelper(AddInfoActivity.this);
        db = mhelper.getWritableDatabase();
    }
    //单机按钮拍照
    private void btnOnClick() {
        btn_camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 获取当前时间
                // 获取当前时间
                Time time = new Time();
                time.setToNow();
                String randtime = String.format("%04d%02d%02d%02d%02d%02d",
                        time.year, time.month + 1, time.monthDay, time.hour, time.minute, time.second); // 修正月份+1
                tmp_path = Environment.getExternalStorageDirectory() + "/images/" + randtime + ".jpg";

                File imgfile = new File(tmp_path); // 创建文件实例
                try {
                    imgfile.createNewFile();
                } catch (Exception e) {
                    e.printStackTrace();
                }

// 使用FileProvider生成内容URI
                Context context = AddInfoActivity.this; // 在 Activity 中
                Uri fileUri = FileProvider.getUriForFile(context, context.getApplicationContext().getPackageName() + ".fileprovider", imgfile);

                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(intent, 11);

            }
        });


        // 从相册选择照片
        btn_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                startActivityForResult(intent, 22);
            }
        });
    }

    // 接受拍好的照片，接受从相册选择的照片----方法系统回调
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) { // 修正参数
        super.onActivityResult(requestCode, resultCode, data); // 调用父类方法
        switch (requestCode) {
            case 11:
                if (resultCode == RESULT_OK) {
                    disp_path = tmp_path;
                    Glide.with(AddInfoActivity.this).load(disp_path).into(img_preview);
                }
                break;
            case 22:
                Uri imageuri = data.getData();
                if (imageuri == null) {
                    return;
                }

                disp_path = UriUtils.uri2File(imageuri).getPath();
                Glide.with(AddInfoActivity.this).load(disp_path).into(img_preview); // 加载选中的相册图片
                break;
            default:
                break;
        }
    }

    private void btnSave() {
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Time time = new Time();
                time.setToNow();
                ContentValues contentValues = new ContentValues();
                contentValues.put("title", edit_title.getText().toString());
                contentValues.put("content", edit_content.getText().toString());

                contentValues.put("imgpath", disp_path);
                contentValues.put("mtime", time.year + "/" + (time.month + 1) + "/" + time.monthDay);
                db.insert("tb_memory", null, contentValues);
                Toast.makeText(AddInfoActivity.this, "保存成功", Toast.LENGTH_SHORT).show(); // 修正为 Toast
                Intent intent = new Intent(AddInfoActivity.this, MainActivity.class);
                startActivity(intent);

                finish();
            }
        });
    }
}
