package com.example.beiwanglu2;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.hardware.SensorAdditionalInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.example.beiwanglu2.bean.MemoAdaper;
import com.example.beiwanglu2.bean.MemoBean;
import com.example.beiwanglu2.db.MyDbHelper;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Button btn_add;
    private RecyclerView recy_view;
    private MyDbHelper mhelper;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        intiView();
        btnonclicknext();
        recyDisplay();

    }
    private void intiView() {
        btn_add = findViewById(R.id.button_add);
        recy_view = findViewById(R.id.recy_view);
        mhelper = new MyDbHelper(MainActivity.this);
        db = mhelper.getWritableDatabase();
    }
    private void btnonclicknext() {
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddInfoActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
    private void recyDisplay() {
        List<MemoBean> arr = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = db.query("tb_memory", null, null, null, null, null, null);
            int titleIndex = cursor.getColumnIndexOrThrow("title");
            int contentIndex = cursor.getColumnIndexOrThrow("content");
            int imgPathIndex = cursor.getColumnIndexOrThrow("imgpath");
            int mtimeIndex = cursor.getColumnIndexOrThrow("mtime");

            while (cursor.moveToNext()) {
                String mytitle = cursor.getString(titleIndex);
                String mycontent = cursor.getString(contentIndex);
                String myimgpath = cursor.getString(imgPathIndex);
                String mymtime = cursor.getString(mtimeIndex);
                MemoBean memoBean = new MemoBean(mytitle, mycontent, myimgpath, mymtime);
                arr.add(memoBean);
            }
        } catch (IllegalArgumentException e) {
            // 处理列不存在的情况
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close(); // 确保游标在使用后关闭
            }
        }

        MemoAdaper adapter = new MemoAdaper(MainActivity.this, arr);
        StaggeredGridLayoutManager st = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
        recy_view.setLayoutManager(st);
        recy_view.setAdapter(adapter);
    }

}