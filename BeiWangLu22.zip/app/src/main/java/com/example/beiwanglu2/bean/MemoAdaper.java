package com.example.beiwanglu2.bean;


import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.beiwanglu2.R;
import com.example.beiwanglu2.db.MyDbHelper;

import java.util.List;
import java.util.Random;

public class MemoAdaper extends RecyclerView.Adapter<MemoAdaper.ViewHolder> {
    private Context mcontext;
    private List<MemoBean> arr1;
    private MyDbHelper mhelper1;
    private SQLiteDatabase db;

    public MemoAdaper(Context mcontext, List<MemoBean> arr1) {
        this.mcontext = mcontext;
        this.arr1 = arr1;
    }

    @NonNull

    @Override
    public MemoAdaper.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(mcontext).inflate(R.layout.recy_item, parent, false);
        ViewHolder mholder = new ViewHolder(view);
        return mholder;
    }
    @RequiresApi(api= Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(@NonNull MemoAdaper.ViewHolder mholder,@SuppressLint("RecyclerView") final int i) {
        final MemoBean memoBean = arr1.get(i);
        mholder.item_title.setText(memoBean.getTitle());
        mholder.item_content.setText(memoBean.getContent());
        mholder.item_time.setText(memoBean.getTime());
        Glide.with(mcontext).load(memoBean.getImgpath()).into(mholder.item_img);
        Random random=new Random();
        int color= Color.argb(255,random.nextInt(256),random.nextInt(256),random.nextInt(256));
        GradientDrawable gradientDrawable =new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.RECTANGLE);
        gradientDrawable.setCornerRadius(10f);
        gradientDrawable.setColor(color);
        mholder.item_layout.setBackground(gradientDrawable);
        mholder.item_layout.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog=new AlertDialog.Builder(mcontext);
                dialog.setMessage("确定删除吗？");
                dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int abc) {
                        mhelper1=new MyDbHelper(mcontext);
                        db=mhelper1.getWritableDatabase();
                        db.delete("tb_memory","title=?",new String[]{arr1.get(i).getTitle()});
                        arr1.remove(i);
                        notifyItemRemoved(i);
                        dialogInterface.dismiss();

                    }
                });
                dialog.setNegativeButton("取消",null);
                dialog.setCancelable(false);
                dialog.create();
                dialog.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return arr1.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView item_title,item_content,item_time;
        ImageView item_img;
        LinearLayout item_layout;
        public ViewHolder(@NonNull View itemView){
            super(itemView);
            item_content=itemView.findViewById(R.id.item_content);
            item_img=itemView.findViewById(R.id.item_image);
            item_layout=itemView.findViewById(R.id.item_layout);
            item_time=itemView.findViewById(R.id.item_time);
            item_title=itemView.findViewById(R.id.item_title);
        }
    }

}

